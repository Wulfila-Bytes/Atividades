class Personagem:
    def __init__(self, nome):
        self.nome = nome
        self.hp = 100

    def get_nome(self):
        return self.nome
    
    def set_nome(self, novo_nome):
        self.nome = novo_nome

    def get_hp(self):
        return self.hp

    def sofrer_dano(self, valor):
        self.hp -= valor
        if self.hp < 0:
            self.hp = 0
    
    def curar(self, valor):
        self.hp += valor
        if self.hp > 100:
            self.hp = 100

personagem = Personagem("Herói")
print("Nome: ", personagem.nome)
print("HP inicial: ", personagem.hp)

personagem.sofrer_dano(30)
print("HP após dano: ", personagem.hp)

personagem.curar(50)
print("HP após cura: ", personagem.hp)

personagem.set_nome("João")

print("Novo nome: ", personagem.nome)
